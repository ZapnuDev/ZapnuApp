package zapnu.dev.mod;

import android.os.*;
import android.content.pm.*;
import android.util.*;
import java.security.MessageDigest;
import android.content.*;
import com.github.javiersantos.appupdater.*;
import com.github.javiersantos.appupdater.enums.*;
import com.github.javiersantos.appupdater.objects.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.widget.Button;
import android.view.View.*;
import android.view.View;

public class MainActivity extends AppCompatActivity 
{
	
	private Button button;
	private Toolbar toolbar;
	private static final String title = (new String(new byte[] {65, 110, 116, 105, 77, 111, 100}));
	private static final String packageName = (new String(new byte[] {122, 97, 112, 110, 117, 46, 100, 101, 118, 46, 109, 111, 100}));
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		//if (getTitle().equals(title))
		//if (getPackageName().equals(packageName)){
        setContentView(R.layout.main);
		/*}else{
			new AlertDialog.Builder(this)
				.setCancelable(false)
				.setTitle("Modifier Alert!")
				.setMessage("This App have Anti Reverse Engineering. Please Contact the Developer of this Application to Allow you to Reverse this App. Is thats Okay with you?")
				.setNegativeButton("Ok", new DialogInterface.OnClickListener()
				{
					public void onClick (DialogInterface dialog, int which)
					{	
						finishAndRemoveTask();
					}
				})
				.setIcon(android.R.drawable.ic_dialog_alert)
				.show();
		}*/
		
		toolbar = (Toolbar)findViewById(R.id.toolbar);
		getSupportActionBar(toolbar);
		toolbar.setTitle(R.string.app_name);
		toolbar.setSubtitle(R.string.hello_world);
		button = (Button)findViewById(R.id.checker);
		button.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					AppUpdater appUpdater = new AppUpdater(MainActivity.this);
					appUpdater.setDisplay(Display.DIALOG);
					appUpdater.setUpdateFrom(UpdateFrom.JSON);
					appUpdater.setUpdateJSON("https://zapnu.ml/app/update.json");
					appUpdater.setTitleOnUpdateAvailable("Update available");
					appUpdater.setContentOnUpdateAvailable("Check out the latest version available of my app!");
					appUpdater.setTitleOnUpdateNotAvailable("Update not available");
					appUpdater.setContentOnUpdateNotAvailable("No update available. Check for updates again later!");
					appUpdater.setButtonUpdate("Update now?");
					appUpdater.setButtonDismiss("Maybe later");
					appUpdater.setButtonDoNotShowAgain("Huh, not interested");
					appUpdater.setIcon(R.drawable.ic_launcher);
					appUpdater.start();
				}
				
			
		});
		
    }

	private void getSupportActionBar(Toolbar toolbar)
	{
		// TODO: Implement this method
	}
	
}
